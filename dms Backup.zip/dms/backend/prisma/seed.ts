import { AccountType, NormalBalance, Prisma, PrismaClient, Role, VehicleStatus } from '@prisma/client';

const prisma = new PrismaClient();

async function upsertVehicleByVin(vin: string, create: Prisma.VehicleCreateInput) {
  const existing = await prisma.vehicle.findFirst({
    where: { vin, deletedAt: null },
  });
  if (existing) {
    return prisma.vehicle.update({
      where: { id: existing.id },
      data: {},
    });
  }
  return prisma.vehicle.create({ data: create });
}

async function main() {
  const admin = await prisma.user.upsert({
    where: { email: 'admin@dealership.local' },
    update: {},
    create: {
      email: 'admin@dealership.local',
      fullName: 'Alex Admin',
      role: Role.ADMIN,
      supabaseUserId: null,
    },
  });

  const salesA = await prisma.user.upsert({
    where: { email: 'sales1@dealership.local' },
    update: {},
    create: {
      email: 'sales1@dealership.local',
      fullName: 'Sam Sales',
      role: Role.SALES,
    },
  });

  const salesB = await prisma.user.upsert({
    where: { email: 'sales2@dealership.local' },
    update: {},
    create: {
      email: 'sales2@dealership.local',
      fullName: 'Riley Rep',
      role: Role.SALES,
    },
  });

  await prisma.user.upsert({
    where: { email: 'accountant@dealership.local' },
    update: {},
    create: {
      email: 'accountant@dealership.local',
      fullName: 'Pat Accountant',
      role: Role.ACCOUNTANT,
    },
  });

  await upsertVehicleByVin('1HGCM82633A123456', {
      datePurchased: new Date('2025-01-10'),
      vin: '1HGCM82633A123456',
      year: 2019,
      make: 'Honda',
      model: 'Accord',
      trim: 'Sport',
      colour: 'Crystal Black',
      odometer: 48200,
      purchasePrice: 18500,
      safetyEstimate: 1200,
      safetyCost: 800,
      floorplanInterestCost: 210.5,
      gas: 60,
      warrantyCost: 450,
      dateSold: null,
      sellingPrice: null,
      safetyCharge: null,
      warrantyCharge: null,
      omvicFee: null,
      buyerName: null,
      referralAmount: 0,
      paymentMethod: null,
      depositAmount: null,
      salesPersonId: salesA.id,
      salesPersonName: salesA.fullName,
      status: VehicleStatus.AVAILABLE,
  });

  await upsertVehicleByVin('2T1BURHE0JC123456', {
      datePurchased: new Date('2024-11-02'),
      vin: '2T1BURHE0JC123456',
      year: 2018,
      make: 'Toyota',
      model: 'Corolla',
      trim: 'LE',
      colour: 'White',
      odometer: 61000,
      purchasePrice: 14250,
      safetyEstimate: 950,
      safetyCost: 700,
      floorplanInterestCost: 180,
      gas: 45,
      warrantyCost: 300,
      dateSold: new Date('2025-02-15'),
      sellingPrice: 16900,
      safetyCharge: 899,
      warrantyCharge: 650,
      omvicFee: 75,
      buyerName: 'Jordan Lee',
      referralAmount: 200,
      paymentMethod: 'Finance',
      depositAmount: 1500,
      salesPersonId: salesB.id,
      salesPersonName: salesB.fullName,
      status: VehicleStatus.SOLD,
  });

  let c1 = await prisma.customer.findFirst({
    where: { fullName: 'Taylor Morgan', deletedAt: null },
  });
  if (!c1) {
    c1 = await prisma.customer.create({
      data: {
        fullName: 'Taylor Morgan',
        email: 'taylor@example.com',
        phone: '+1-555-0101',
      },
    });
  }

  let c2 = await prisma.customer.findFirst({
    where: { fullName: 'Casey Rivera', deletedAt: null },
  });
  if (!c2) {
    c2 = await prisma.customer.create({
      data: {
        fullName: 'Casey Rivera',
        email: 'casey@example.com',
        phone: '+1-555-0102',
      },
    });
  }

  const honda = await prisma.vehicle.findFirst({
    where: { vin: '1HGCM82633A123456', deletedAt: null },
  });
  if (honda) {
    await prisma.customerVehicle.upsert({
      where: {
        customerId_vehicleId: { customerId: c1.id, vehicleId: honda.id },
      },
      update: {},
      create: {
        customerId: c1.id,
        vehicleId: honda.id,
        role: 'INTERESTED',
      },
    });
  }

  const leadCount = await prisma.lead.count();
  if (leadCount === 0) {
    await prisma.lead.create({
      data: {
        fullName: 'Alex Prospect',
        phone: '+1-555-0199',
        email: 'alex.prospect@example.com',
        status: 'NEW_LEAD',
        source: 'WEB',
        summary: 'Asked about SUVs under $25k',
        customerId: c1.id,
        vehicleId: honda?.id ?? null,
      },
    });
  }

  const dealCount = await prisma.deal.count();
  if (dealCount === 0) {
    await prisma.deal.create({
      data: {
        customerId: c2.id,
        vehicleId: honda?.id,
        title: 'Corolla follow-up',
        value: 16900,
        stage: 'PROPOSAL',
        notes: 'Sample deal linked to customer + optional vehicle',
      },
    });
  }

  const taskCount = await prisma.crmTask.count();
  if (taskCount === 0) {
    const deal = await prisma.deal.findFirst({ where: { customerId: c2.id } });
    await prisma.crmTask.create({
      data: {
        customerId: c2.id,
        dealId: deal?.id,
        title: 'Send financing options',
        description: 'Follow up with pre-approval numbers',
        dueAt: new Date(Date.now() + 3 * 86400000),
        status: 'OPEN',
      },
    });
  }

  const coaSeed = [
    { code: '1000', name: 'Cash', type: AccountType.ASSET, normalBalance: NormalBalance.DEBIT },
    { code: '1150', name: 'Accounts receivable', type: AccountType.ASSET, normalBalance: NormalBalance.DEBIT },
    { code: '1200', name: 'Vehicle inventory', type: AccountType.ASSET, normalBalance: NormalBalance.DEBIT },
    { code: '2000', name: 'Accounts payable', type: AccountType.LIABILITY, normalBalance: NormalBalance.CREDIT },
    { code: '3000', name: 'Owner equity', type: AccountType.EQUITY, normalBalance: NormalBalance.CREDIT },
    { code: '4000', name: 'Vehicle sales', type: AccountType.REVENUE, normalBalance: NormalBalance.CREDIT },
    { code: '5000', name: 'Cost of goods sold', type: AccountType.EXPENSE, normalBalance: NormalBalance.DEBIT },
    { code: '5100', name: 'Reconditioning expense', type: AccountType.EXPENSE, normalBalance: NormalBalance.DEBIT },
  ];
  for (const row of coaSeed) {
    await prisma.glAccount.upsert({
      where: { code: row.code },
      update: {},
      create: row,
    });
  }

  const sold = await prisma.vehicle.findFirst({
    where: { vin: '2T1BURHE0JC123456', deletedAt: null },
  });
  if (sold) {
    const existing = await prisma.vehicleLedgerEntry.count({
      where: { vehicleId: sold.id },
    });
    if (existing === 0) {
      await prisma.vehicleLedgerEntry.createMany({
        data: [
          {
            vehicleId: sold.id,
            category: 'RECON',
            amount: 700,
            description: 'Safety & certification',
            occurredOn: new Date('2024-11-05'),
          },
          {
            vehicleId: sold.id,
            category: 'FLOORPLAN',
            amount: 180,
            description: 'Floorplan interest',
            occurredOn: new Date('2025-02-01'),
          },
        ],
      });
    }
  }

  console.log('Seed complete. Admin user id:', admin.id);
}

main()
  .then(async () => prisma.$disconnect())
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
