'use client';

import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { AuthBar } from '@/components/AuthBar';
import { ReportTable } from '@/components/reports/ReportTable';
import {
  ApiError,
  downloadIncomeStatementCsv,
  fetchIncomeStatement,
  type IncomeStatementResponse,
} from '@/lib/api';

function TotalsCard({
  label,
  value,
  emphasis,
}: {
  label: string;
  value: string;
  emphasis?: boolean;
}) {
  return (
    <div
      className={`rounded-xl border px-4 py-3 ${
        emphasis
          ? 'border-sky-500/35 bg-sky-950/20 ring-1 ring-sky-500/15'
          : 'border-slate-800/80 bg-slate-900/30'
      }`}
    >
      <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`mt-1 text-lg font-semibold tabular-nums ${emphasis ? 'text-sky-100' : 'text-slate-100'}`}>
        {value}
      </p>
    </div>
  );
}

export default function IncomeStatementPage() {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [appliedStart, setAppliedStart] = useState<string | undefined>();
  const [appliedEnd, setAppliedEnd] = useState<string | undefined>();
  const [data, setData] = useState<IncomeStatementResponse | null>(null);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [csvBusy, setCsvBusy] = useState(false);
  const [csvError, setCsvError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    setBusy(true);
    try {
      const res = await fetchIncomeStatement({
        startDate: appliedStart,
        endDate: appliedEnd,
      });
      setData(res);
    } catch (e) {
      setData(null);
      setError(e instanceof Error ? e.message : 'Failed to load income statement');
    } finally {
      setBusy(false);
    }
  }, [appliedStart, appliedEnd]);

  useEffect(() => {
    void load();
  }, [load]);

  function applyFilters() {
    setAppliedStart(startDate || undefined);
    setAppliedEnd(endDate || undefined);
  }

  function clearDates() {
    setStartDate('');
    setEndDate('');
    setAppliedStart(undefined);
    setAppliedEnd(undefined);
  }

  async function handleDownloadCsv() {
    setCsvError(null);
    setCsvBusy(true);
    try {
      const blob = await downloadIncomeStatementCsv({
        startDate: appliedStart,
        endDate: appliedEnd,
      });
      const filename = `income_statement_${data?.startDate ?? 'export'}_${data?.endDate ?? 'export'}.csv`;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.rel = 'noopener';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
      const msg =
        e instanceof ApiError
          ? e.message
          : e instanceof Error
            ? e.message
            : 'Could not download CSV.';
      setCsvError(msg);
    } finally {
      setCsvBusy(false);
    }
  }

  return (
    <main className="mx-auto flex max-w-5xl flex-col gap-6 px-4 py-8 lg:px-8">
      <header className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-sky-400">Accounting</p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight text-white">Income statement</h1>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-400">
            Profit &amp; loss from posted GL activity. Leave dates empty to use the API default range
            (year-to-date through today).
          </p>
          <nav className="mt-4 flex flex-wrap gap-3 text-sm">
            <Link href="/" className="text-slate-400 underline-offset-2 hover:text-slate-200 hover:underline">
              Home
            </Link>
            <span className="text-slate-600">·</span>
            <Link
              href="/reports/balance-sheet"
              className="font-medium text-sky-400/90 underline-offset-2 hover:text-sky-300 hover:underline"
            >
              Balance sheet
            </Link>
          </nav>
        </div>
        <AuthBar />
      </header>

      <section className="flex flex-col gap-4 rounded-2xl border border-slate-800/80 bg-slate-900/25 p-4 ring-1 ring-white/[0.02] backdrop-blur-sm">
        <div className="flex flex-wrap items-end gap-4">
          <label className="flex flex-col gap-1 text-[11px] font-medium uppercase tracking-wide text-slate-500">
            Start date
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="rounded-xl border border-slate-700/80 bg-slate-950 px-3 py-2.5 text-sm font-medium text-slate-100 outline-none transition hover:border-slate-600 focus:border-sky-500/50 focus:ring-1 focus:ring-sky-500/20"
            />
          </label>
          <label className="flex flex-col gap-1 text-[11px] font-medium uppercase tracking-wide text-slate-500">
            End date
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="rounded-xl border border-slate-700/80 bg-slate-950 px-3 py-2.5 text-sm font-medium text-slate-100 outline-none transition hover:border-slate-600 focus:border-sky-500/50 focus:ring-1 focus:ring-sky-500/20"
            />
          </label>
          <button
            type="button"
            onClick={applyFilters}
            className="rounded-xl bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-sky-950/30 transition hover:bg-sky-500"
          >
            Apply range
          </button>
          <button
            type="button"
            onClick={clearDates}
            className="rounded-xl border border-slate-600/90 bg-slate-800/80 px-4 py-2.5 text-sm font-semibold text-slate-200 transition hover:border-slate-500 hover:bg-slate-700/90"
          >
            Clear (use default)
          </button>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => void handleDownloadCsv()}
            disabled={csvBusy || busy || !data}
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-600/90 bg-slate-800/80 px-4 py-2.5 text-sm font-semibold text-slate-100 shadow-sm transition hover:border-slate-500 hover:bg-slate-700/90 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {csvBusy ? (
              <span
                className="h-4 w-4 animate-spin rounded-full border-2 border-slate-400/30 border-t-sky-400"
                aria-hidden
              />
            ) : (
              <svg
                className="h-4 w-4 text-slate-300"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
                aria-hidden
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                />
              </svg>
            )}
            {csvBusy ? 'Downloading…' : 'Download CSV'}
          </button>
          {data ? (
            <span className="text-xs text-slate-500">
              <span className="mr-4 inline-block">
                Basis: <span className="font-mono text-slate-400">{data.basis}</span>
              </span>
              Period:{' '}
              <span className="font-mono text-slate-400">
                {data.startDate} → {data.endDate}
              </span>
            </span>
          ) : null}
        </div>
      </section>

      {csvError ? (
        <div
          role="alert"
          className="flex flex-col gap-2 rounded-2xl border border-amber-500/35 bg-amber-950/25 px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
        >
          <p className="text-sm text-amber-100/90">
            <span className="font-semibold text-amber-200">Download failed.</span> {csvError}
          </p>
          <button
            type="button"
            onClick={() => setCsvError(null)}
            className="shrink-0 text-sm font-medium text-amber-300/90 underline-offset-2 hover:underline"
          >
            Dismiss
          </button>
        </div>
      ) : null}

      {error ? (
        <div
          role="alert"
          className="rounded-2xl border border-rose-500/35 bg-rose-950/30 px-5 py-4 shadow-sm"
        >
          <p className="text-sm font-semibold text-rose-200">Could not load report</p>
          <p className="mt-1 text-sm text-rose-100/85">{error}</p>
          <button
            type="button"
            onClick={() => void load()}
            className="mt-3 rounded-xl border border-rose-400/40 bg-rose-500/15 px-4 py-2 text-sm font-semibold text-rose-100 transition hover:bg-rose-500/25"
          >
            Retry
          </button>
        </div>
      ) : null}

      {busy && !data ? (
        <p className="text-sm text-slate-500">Loading…</p>
      ) : data ? (
        <div className="flex flex-col gap-8">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            <TotalsCard label="Total revenue" value={data.totals.totalRevenue} />
            <TotalsCard label="Cost of goods sold" value={data.totals.totalCostOfGoodsSold} />
            <TotalsCard label="Gross profit" value={data.totals.grossProfit} />
            <TotalsCard label="Operating expenses" value={data.totals.totalExpenses} />
            <TotalsCard label="Net profit" value={data.totals.netProfit} emphasis />
          </div>

          <section>
            <h2 className="mb-3 text-sm font-semibold text-slate-200">Revenue</h2>
            <ReportTable rows={data.revenue} caption="Revenue accounts" />
          </section>

          <section>
            <h2 className="mb-3 text-sm font-semibold text-slate-200">Cost of goods sold</h2>
            <ReportTable rows={data.costOfGoodsSold} caption="Cost of goods sold" />
          </section>

          <section>
            <h2 className="mb-3 text-sm font-semibold text-slate-200">Operating expenses</h2>
            <ReportTable rows={data.operatingExpenses} caption="Operating expenses" />
          </section>
        </div>
      ) : null}
    </main>
  );
}
