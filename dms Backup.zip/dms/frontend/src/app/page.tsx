import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl flex-col justify-center gap-6 px-6 py-16">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-sky-400">
          Dealer DMS
        </p>
        <h1 className="mt-3 text-4xl font-semibold text-white">Operations hub</h1>
        <p className="mt-3 text-slate-400">
          Modular inventory, CRM, accounting, and dashboards backed by NestJS + Prisma + Supabase
          Auth/Realtime.
        </p>
      </div>
      <div className="flex flex-wrap gap-3">
        <Link
          href="/inventory"
          className="rounded-xl bg-sky-600 px-5 py-3 text-sm font-semibold text-white hover:bg-sky-500"
        >
          Open inventory
        </Link>
        <Link
          href="/crm"
          className="rounded-xl border border-slate-700 bg-slate-900/50 px-5 py-3 text-sm font-semibold text-slate-100 hover:bg-slate-800"
        >
          CRM pipeline
        </Link>
        <Link
          href="/reports/income-statement"
          className="rounded-xl border border-slate-700 bg-slate-900/50 px-5 py-3 text-sm font-semibold text-slate-100 hover:bg-slate-800"
        >
          Income statement
        </Link>
        <Link
          href="/reports/balance-sheet"
          className="rounded-xl border border-slate-700 bg-slate-900/50 px-5 py-3 text-sm font-semibold text-slate-100 hover:bg-slate-800"
        >
          Balance sheet
        </Link>
        <span className="self-center text-xs text-slate-500">
          API: <code className="font-mono text-slate-300">/vehicles</code>,{' '}
          <code className="font-mono text-slate-300">/crm/*</code>,{' '}
          <code className="font-mono text-slate-300">/reports/*</code>
        </span>
      </div>
    </main>
  );
}
