# Dealer Management System (DMS)

Production-oriented monorepo for a used-car dealership: **NestJS + Prisma + PostgreSQL** API, **Next.js (App Router) + Tailwind** web app, **Supabase Auth + Realtime**.

## Architecture

| Module        | Scope |
|---------------|-------|
| **Inventory** | Vehicles CRUD, tax + profit engine, filters |
| **CRM**       | Customers, leads, deals, tasks; notes & interaction logs; customer↔vehicle links |
| **Accounting**| Double-entry GL (`GlAccount`, `JournalEntry` / `JournalLine`), trial balance & account ledger; legacy `VehicleLedgerEntry` per vehicle |
| **Dashboard** | Fleet counts + realized profit + capital on lot |

### Roles

- **ADMIN / SALES**: create/update/delete vehicles, CRM writes.
- **ACCOUNTANT**: vehicle reads, accounting writes.
- **JWT**: verified with `SUPABASE_JWT_SECRET` (HS256). Map Supabase `app_metadata.role` to `ADMIN`, `SALES`, or `ACCOUNTANT`.

## Inventory economics

- **Purchase tax**: 13% of `purchasePrice` → `taxCost`; `totalPurchasePrice = purchasePrice + taxCost`.
- **Safety / gas / warranty taxes**: 13% of respective pre-tax inputs.
- **Sell tax**: 13% of `(sellingPrice + safetyCharge + warrantyCharge + omvicFee)` — **excluded from profit** (pass-through).
- **Profit** (sold units only):  
  `(sellingPrice + safetyCharge + warrantyCharge + omvicFee)`  
  minus `totalPurchasePrice`, safety+tax, floorplan, gas+tax, warranty+tax, referral.  
  `depositAmount` and `safetyEstimate` are informational only.
- **Lot days**: days from `datePurchased` to `dateSold` if sold, else to today. UI colors: `<30` green, `30–60` yellow, `>60` red.

**Single source of truth** for tax, total purchase, profit, and lot days: npm workspace package **`@dms/inventory-calculations`** (`packages/inventory-calculations/`). The Nest **`InventoryCalculationsService`** and the Next.js UI import from that package (integer cents internally).

From the **repo root** (after `npm install`, which builds the package via `postinstall`):

- `npm run test:inventory` — Jest tests in `@dms/inventory-calculations` plus **`vehicle-business-rules.spec.ts`**
- `npm run test:inventory-calculations` — Jest only (shared package)

From **`backend/`** only: `npm run test:vehicle-rules` runs business-rule specs.

**Validation:** field rules live on `CreateVehicleDto` (Nest `ValidationPipe`). Cross-field rules (sale bundle, `dateSold` ≥ `datePurchased`, calendar dates, 13% profit inputs) run in `validateCreateVehicleBusinessRules` / `validateUpdateVehicleBusinessRules` so invalid vehicles cannot be persisted.

## Prerequisites

- Node.js 20+
- PostgreSQL 15+ (or Supabase-hosted Postgres)
- Supabase project (Auth + Realtime)

## Database

```bash
cd backend
cp .env.example .env
# edit DATABASE_URL
npm install
npx prisma migrate deploy
npx prisma db seed
```

## API

```bash
cd backend
npm run start:dev
```

Key routes:

- `POST/GET /vehicles`, `GET/PATCH/DELETE /vehicles/:id`
- `GET /users/salespeople` (inventory filter)
- **CRM** (JWT; writes require ADMIN or SALES):  
  `GET/POST/PATCH/DELETE /crm/customers`, nested `.../notes`, `.../interactions`, `.../vehicles`  
  `GET/POST/PATCH/DELETE /crm/leads` (stages: `NEW_LEAD`, `CONTACTED`, `NEGOTIATING`, `CLOSED`)  
  `GET/POST/PATCH/DELETE /crm/deals`  
  `GET/POST/PATCH/DELETE /crm/tasks`  
  **CRM ↔ inventory:** linking a lead to a vehicle keeps a `CustomerVehicle` **INTERESTED** row in sync (sold units are rejected). Moving a deal to **CLOSED_WON** requires a vehicle and then sets that unit to **SOLD** in inventory (`status`, `dateSold`, `buyerName` from the customer, `sellingPrice` from the deal) and upserts **CustomerVehicle** as **BUYER**.  
  **Inventory ↔ GL:** when a vehicle is marked sold (deal close or inventory edit), the API posts **two** balanced, POSTED journals if chart accounts exist: (1) Dr Cash or **1150** A/R · Cr **4000** revenue — pre-tax sale total from vehicle lines (`sellingPrice` + safety/warranty/OMVIC charges, same basis as profit); (2) Dr **5000** COGS · Cr **1200** inventory — acquisition cost (same components as `computeVehicleProfit`). Links stored on `Vehicle.glRevenueJournalId` / `glCogsJournalId` for idempotency.
- **Accounting (double-entry)** (JWT; **ADMIN** or **ACCOUNTANT** for writes):  
  `GET/POST/PATCH /accounting/accounts` (chart of accounts)  
  `GET/POST/PATCH/DELETE /accounting/journal-entries`, `POST /accounting/journal-entries/:id/post` (balanced debits/credits; DB check enforces one-sided lines)  
  `GET /accounting/general-ledger?accountId=&from=&to=` (posted activity + running balance)  
  `GET /accounting/trial-balance?asOf=`  
  **Reports** (same roles): `GET /accounting/reports/profit-loss?from=&to=` (GL revenue & expense accounts, net income), `GET /accounting/reports/vehicle-profit?from=&to=&page=&pageSize=` (sold units, inventory profit engine), `GET /accounting/reports/monthly?from=&to=` (per-month vehicle + GL rollups)  
  Legacy vehicle lines: `GET /accounting/vehicles/:vehicleId/ledger`, `POST /accounting/ledger`
- `GET /dashboard/summary`

### Local auth shortcut

Set `AUTH_DISABLED=true` in `backend/.env` and `NEXT_PUBLIC_AUTH_DISABLED=true` in `frontend/.env.local` to skip JWT crypto while UI/API iterate. **Never enable in production.**

## Web app

```bash
cd frontend
cp .env.example .env.local
npm install
npm run dev
```

Open `http://localhost:3000/inventory`, `http://localhost:3000/crm`, and the Kanban lead board at `http://localhost:3000/crm/pipeline`.

### Supabase Realtime

1. In Supabase SQL editor, enable replication for the `Vehicle` table:

   ```sql
   alter publication supabase_realtime add table "Vehicle";
   alter table "Vehicle" replica identity full;
   ```

2. Ensure RLS policies allow `authenticated` roles to `select` vehicles (and service role for API bypass if you connect Prisma with a direct string).

3. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.

The UI subscribes to `postgres_changes` on `"Vehicle"` and refetches the grid on any mutation (including changes from other browsers).

## Production checklist

- Lock down `AUTH_DISABLED`.
- Use strong database credentials; prefer Supavisor pooler URLs for serverless frontends if applicable.
- Configure `FRONTEND_ORIGIN` to your deployed web origin(s).
- Align Supabase user metadata roles with Prisma `Role` enum.
- Run `npm run build` in both apps inside your CI pipeline.

## Folder layout

```
dms/
  packages/
    inventory-calculations/   # shared tax / profit / lot-days (@dms/inventory-calculations)
  backend/        # NestJS + Prisma
  frontend/       # Next.js App Router
  README.md
```
